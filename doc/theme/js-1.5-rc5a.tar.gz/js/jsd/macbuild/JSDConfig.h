

#include "JavaDefines.h"

/* Nothing to do here. If you need JSD-specific defines, add them here */
